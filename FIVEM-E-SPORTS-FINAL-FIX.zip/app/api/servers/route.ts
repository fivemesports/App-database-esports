import { NextResponse } from "next/server";
import { servers as cfxServers } from "cfx-api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const revalidate = 0;
export const maxDuration = 60;

type NormalizedServer = {
  id: string;
  name: string;
  players: number;
  maxPlayers: number;
  country: string;
  endpoint: string;
  language: string;
  tags: string[];
};

type ApiPayload = {
  ok: true;
  servers: NormalizedServer[];
  indonesiaServers: NormalizedServer[];
  count: number;
  totalPlayers: number;
  totalSlots: number;
  source: string;
  updatedAt: string;
};

type CfxRecord = Record<string, unknown>;

const SOURCE = "Cfx.re public server browser (Cfx API decoder)";
const CACHE_TTL_MS = 5 * 60 * 1000;
const GLOBAL_RESULT_LIMIT = 1000;
const INDONESIA_RESULT_LIMIT = 100;
const FETCH_TIMEOUT_MS = 50_000;

let memoryCache: { payload: ApiPayload; expiresAt: number } | null = null;

function asRecord(value: unknown): CfxRecord {
  return value !== null && typeof value === "object" ? value as CfxRecord : {};
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function asNumber(value: unknown): number {
  const number = typeof value === "number" ? value : Number(value);
  return Number.isFinite(number) && number >= 0 ? number : 0;
}

function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.filter((item): item is string => typeof item === "string");
  if (typeof value === "string") return value.split(/[,; ]+/).map(item => item.trim()).filter(Boolean);
  return [];
}

function normalizeServer(value: unknown, index: number): NormalizedServer | null {
  const server = asRecord(value);
  const vars = asRecord(server.publicVariables);
  const hostname = asString(server.hostname).replace(/\^[0-9]/g, "").trim();
  if (!hostname) return null;

  const locale = asString(server.locale, asString(vars.locale, "Unknown"));
  const tags = asStringArray(server.tags);
  const variableTags = asString(vars.tags);
  const metadata = [hostname, locale, variableTags, asString(server.projectName), asString(server.projectDesc)]
    .filter(Boolean).join(" ");
  const isIndonesia = /(^|[^a-z])(indonesia|indonesian|bahasa indonesia)([^a-z]|$)/i.test(metadata)
    || /^id(?:[-_]|$)/i.test(locale)
    || tags.some(tag => /^(indonesia|indonesian|bahasa-indonesia)$/i.test(tag));
  const endpoint = asString(server.connectEndpoint)
    || asString(Array.isArray(server.connectedEndpoints) ? server.connectedEndpoints[0] : "")
    || asString(server.id);
  const id = asString(server.id, endpoint || `server-${index}`);

  return {
    id,
    name: hostname,
    players: asNumber(server.playersCount),
    maxPlayers: asNumber(server.maxPlayers),
    country: isIndonesia ? "Indonesia" : "Global",
    endpoint,
    language: locale || "Unknown",
    tags: [...new Set([...tags, ...asStringArray(variableTags)])].slice(0, 12)
  };
}

function respond(payload: unknown, status = 200) {
  return NextResponse.json(payload, {
    status,
    headers: {
      "Cache-Control": status === 200
        ? "public, s-maxage=300, stale-while-revalidate=600"
        : "no-store, max-age=0"
    }
  });
}

async function fetchAllServersWithTimeout(): Promise<unknown[]> {
  let timeoutId: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error("Permintaan ke Cfx.re melewati batas 50 detik. Coba lagi beberapa menit lagi.")), FETCH_TIMEOUT_MS);
  });

  try {
    // cfx-api decodes the current Cfx.re Protobuf stream and follows streamRedir.
    return await Promise.race([cfxServers.all(), timeout]);
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
  }
}

export async function GET() {
  const now = Date.now();
  if (memoryCache && memoryCache.expiresAt > now) {
    return respond(memoryCache.payload);
  }

  try {
    const rawServers = await fetchAllServersWithTimeout();
    const allServers = rawServers
      .map((server, index) => normalizeServer(server, index))
      .filter((server): server is NormalizedServer => server !== null)
      .sort((a, b) => b.players - a.players || a.name.localeCompare(b.name));

    if (allServers.length === 0) {
      throw new Error("Cfx.re berhasil dihubungi, tetapi tidak ada record server yang bisa dibaca. Format sumber mungkin berubah.");
    }

    const totalPlayers = allServers.reduce((sum, server) => sum + server.players, 0);
    const totalSlots = allServers.reduce((sum, server) => sum + server.maxPlayers, 0);
    const indonesiaServers = allServers
      .filter(server => server.country === "Indonesia")
      .slice(0, INDONESIA_RESULT_LIMIT);

    const payload: ApiPayload = {
      ok: true,
      servers: allServers.slice(0, GLOBAL_RESULT_LIMIT),
      indonesiaServers,
      count: allServers.length,
      totalPlayers,
      totalSlots,
      source: SOURCE,
      updatedAt: new Date().toISOString()
    };

    memoryCache = { payload, expiresAt: Date.now() + CACHE_TTL_MS };
    return respond(payload);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Kesalahan tidak diketahui saat mengambil data Cfx.re.";
    return respond({
      ok: false,
      servers: [],
      indonesiaServers: [],
      count: 0,
      totalPlayers: 0,
      totalSlots: 0,
      source: SOURCE,
      error: message,
      updatedAt: new Date().toISOString()
    }, 502);
  }
}
