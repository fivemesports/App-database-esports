import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FIVEM E-SPORTS — Global Server Intelligence",
  description: "Pantau performa server FiveM, ranking Indonesia, duel server, dan tren komunitas dalam satu dashboard.",
  metadataBase: new URL("https://fivem-esports.vercel.app")
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
