"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Activity, ArrowDownRight, ArrowUpRight, ChevronDown, ExternalLink, Globe2, Menu, Newspaper, Radio, RefreshCw, Search, ShieldCheck, Swords, Trophy, Users, X } from "lucide-react";

type Server = { id: string; name: string; players: number; maxPlayers: number; country: string; endpoint: string; language: string; tags: string[] };
type ApiResponse = { ok: boolean; servers: Server[]; indonesiaServers?: Server[]; count?: number; totalPlayers?: number; totalSlots?: number; source?: string; error?: string; updatedAt?: string };

const fmt = (n: number) => new Intl.NumberFormat("id-ID").format(n);
const officialLinks = [
  { label: "FiveM Official", href: "https://fivem.net/", desc: "Download FiveM" },
  { label: "Rockstar Games", href: "https://www.rockstargames.com/", desc: "Official website" },
  { label: "Buy GTA V", href: "https://www.rockstargames.com/gta-v", desc: "Official game page" }
];

export default function Home() {
  const [servers, setServers] = useState<Server[]>([]);
  const [indonesiaServers, setIndonesiaServers] = useState<Server[]>([]);
  const [discoveredCount, setDiscoveredCount] = useState(0);
  const [totalPlayers, setTotalPlayers] = useState(0);
  const [totalSlots, setTotalSlots] = useState(0);
  const [status, setStatus] = useState<"loading" | "live" | "error">("loading");
  const [updated, setUpdated] = useState("");
  const [error, setError] = useState("");
  const [active, setActive] = useState("Overview");
  const [search, setSearch] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [duelA, setDuelA] = useState("");
  const [duelB, setDuelB] = useState("");

  const load = useCallback(async () => {
    try {
      const res = await fetch("/api/servers", { cache: "no-store" });
      const data: ApiResponse = await res.json();
      if (!res.ok || !data.ok) throw new Error(data.error || "Data server tidak tersedia.");
      const nextServers = data.servers || [];
      setServers(nextServers);
      setIndonesiaServers(data.indonesiaServers || []);
      setDiscoveredCount(data.count ?? nextServers.length);
      setTotalPlayers(data.totalPlayers ?? nextServers.reduce((sum, server) => sum + server.players, 0));
      setTotalSlots(data.totalSlots ?? nextServers.reduce((sum, server) => sum + server.maxPlayers, 0));
      setUpdated(data.updatedAt || new Date().toISOString());
      setStatus("live");
      setError("");
    } catch (e) {
      setStatus("error");
      setError(e instanceof Error ? e.message : "Gagal memuat data Cfx.re.");
    }
  }, []);

  useEffect(() => {
    load();
    const timer = window.setInterval(load, 300_000);
    return () => window.clearInterval(timer);
  }, [load]);

  const sorted = useMemo(() => [...servers].sort((a, b) => b.players - a.players), [servers]);
  const filtered = useMemo(() => sorted.filter(s => s.name.toLowerCase().includes(search.toLowerCase())), [sorted, search]);
  const topIndonesia = useMemo(() => indonesiaServers.slice(0, 10), [indonesiaServers]);
  const duelOne = sorted.find(s => s.id === duelA);
  const duelTwo = sorted.find(s => s.id === duelB);
  const stamp = updated ? new Date(updated).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "--:--";

  const nav = [
    { label: "Overview", icon: Activity },
    { label: "Global Rankings", icon: Trophy },
    { label: "Indonesia Top 10", icon: Users },
    { label: "Server Duel", icon: Swords },
    { label: "World Map", icon: Globe2 },
    { label: "Breaking News", icon: Newspaper }
  ];

  const go = (label: string) => {
    setActive(label);
    setMobileMenu(false);
    const ids: Record<string, string> = { "Overview": "overview", "Global Rankings": "global", "Indonesia Top 10": "indonesia", "Server Duel": "duel", "World Map": "worldmap", "Breaking News": "news" };
    document.getElementById(ids[label] || "overview")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <main>
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <a className="brand" href="#overview" onClick={() => setActive("Overview")}>
          <img src="/logo.png" alt="FIVEM E-SPORTS logo" />
          <span><strong>FIVEM <b>E-SPORTS</b></strong><small>SERVER INTELLIGENCE</small></span>
          <button className="close-menu" aria-label="Close menu" onClick={(e) => { e.preventDefault(); setMobileMenu(false); }}><X size={18}/></button>
        </a>
        <div className="nav-caption">MONITORING CENTER</div>
        <nav>
          {nav.map(item => {
            const Icon = item.icon;
            return <button key={item.label} className={`nav-item ${active === item.label ? "active" : ""}`} onClick={() => go(item.label)}><Icon size={17}/><span>{item.label}</span>{item.label === "Global Rankings" && <ChevronDown className="nav-chevron" size={14}/>}</button>;
          })}
        </nav>
        <div className="sidebar-bottom">
          <div className="live-card"><span className={`live-dot ${status === "error" ? "dot-error" : ""}`}/><div><strong>{status === "live" ? "MONITOR ONLINE" : status === "error" ? "SOURCE UNAVAILABLE" : "CONNECTING..."}</strong><small>{status === "live" ? "Cfx.re public data" : status === "error" ? "Retrying automatically" : "Connecting to source"}</small></div></div>
          <div className="sidebar-social"><span>FOLLOW THE SCENE</span><div><a href="https://www.tiktok.com/@fivemesports.id" target="_blank" rel="noreferrer">TikTok ↗</a><a href="https://www.instagram.com/fivemesports.id/" target="_blank" rel="noreferrer">Instagram ↗</a></div></div>
          <small className="copyright">Independent community project · Not affiliated with Cfx.re or Rockstar Games.</small>
        </div>
      </aside>

      {mobileMenu && <button className="scrim" aria-label="Close navigation" onClick={() => setMobileMenu(false)}/>}
      <section className="main-area">
        <header className="topbar">
          <button className="menu-toggle" aria-label="Open menu" onClick={() => setMobileMenu(true)}><Menu size={20}/></button>
          <div className="breadcrumb">DASHBOARD <span>/</span> <b>{active.toUpperCase()}</b></div>
          <div className="topbar-right"><span className="updated">UPDATED {stamp}</span><span className={`status-pill ${status}`}><i/> {status === "live" ? "LIVE DATA" : status === "error" ? "OFFLINE" : "CONNECTING"}</span><button className="icon-button" onClick={load} aria-label="Refresh data"><RefreshCw size={16}/></button></div>
        </header>

        <section className="hero" id="overview">
          <video className="hero-video" src="/banner.mp4" autoPlay muted loop playsInline aria-label="FIVEM E-SPORTS motion banner"/>
          <div className="hero-shade"/>
          <div className="hero-content">
            <div className="eyebrow"><span className="eyebrow-line"/> THE GLOBAL ROLEPLAY INDEX</div>
            <h1>TRACK THE SCENE.<br/><em>OWN THE MOMENT.</em></h1>
            <p>Platform independen untuk memantau performa server FiveM, membaca tren komunitas, dan mengikuti persaingan roleplay dari Indonesia hingga dunia.</p>
            <div className="hero-actions"><button className="btn-primary" onClick={() => go("Global Rankings")}>Explore Rankings <ArrowUpRight size={16}/></button><button className="btn-ghost" onClick={() => go("World Map")}><Globe2 size={16}/> Explore World Map</button></div>
          </div>
          <div className="hero-index"><span>FES / 001</span><b>GLOBAL<br/>INTELLIGENCE</b><i>EST. 2026</i></div>
          <div className="hero-bottom"><span><span className="live-dot"/> PUBLIC SERVER MONITOR</span><span>DATA SOURCE: CFX.RE</span><span>REFRESH CYCLE: 5 MIN</span></div>
        </section>

        <section className="content">
          <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> LIVE OVERVIEW</div><h2>Global <em>Performance</em></h2><p>A real-time snapshot of the public server browser.</p></div><button className="subtle-button" onClick={load}><RefreshCw size={14}/> Refresh data</button></div>

          {status === "error" && <div className="notice error"><Radio size={18}/><div><strong>Data Cfx.re belum bisa dimuat.</strong><p>{error}. Endpoint publik atau akses dari hosting mungkin berubah/terbatas. Panel tidak menampilkan angka contoh sebagai data live.</p></div></div>}

          <div className="stats-grid">
            <Stat icon={<Globe2/>} label="DISCOVERED SERVERS" value={fmt(discoveredCount)} foot="All public listings discovered" />
            <Stat icon={<Users/>} label="TOTAL PLAYERS" value={fmt(totalPlayers)} foot="Current players across discovered listings" />
            <Stat icon={<Activity/>} label="TOTAL PLAYER SLOTS" value={fmt(totalSlots)} foot="Reported capacity across discovered listings" />
            <Stat icon={<Radio/>} label="DATA STATUS" value={status === "live" ? "LIVE" : status === "error" ? "OFFLINE" : "SYNC"} foot={status === "live" ? `Last sync ${stamp}` : "Waiting for source"} live={status === "live"} />
          </div>

          <section className="panel" id="global">
            <div className="panel-head"><div><div className="eyebrow">WORLDWIDE LEADERBOARD</div><h3>Global Server <em>Rankings</em></h3></div><span className="count-tag">{fmt(sorted.length)} SERVERS</span></div>
            <div className="table-tools"><div className="searchbox"><Search size={15}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search public server name..."/></div><span className="muted-note">Ranked by current players</span></div>
            <ServerTable servers={filtered.slice(0, 10)} empty={status === "live" ? "No servers match your search." : "Waiting for Cfx.re public server data."}/>
            <div className="panel-foot"><span>Source: Cfx.re public server browser</span><span>Refreshes every 5 minutes</span></div>
          </section>

          <section className="panel" id="indonesia">
            <div className="panel-head"><div><div className="eyebrow">INDONESIA SPOTLIGHT</div><h3>Top 10 <em>Indonesia</em></h3><p>Server dengan sinyal negara/bahasa Indonesia yang terdeteksi pada data publik.</p></div><span className="count-tag red-tag">ID / TOP 10</span></div>
            <ServerTable servers={topIndonesia} empty="Belum ada server yang bisa diklasifikasikan secara meyakinkan sebagai Indonesia. Data negara tidak selalu disediakan oleh server browser."/>
            <div className="panel-foot"><span>Country detection is best-effort</span><span>Not an official Cfx.re ranking</span></div>
          </section>

          <section className="duel-grid" id="duel">
            <div className="panel duel-panel">
              <div className="panel-head"><div><div className="eyebrow">HEAD-TO-HEAD</div><h3>Server <em>Duel Battle</em></h3><p>Bandingkan jumlah pemain dua server dari data saat ini.</p></div><Swords className="accent-icon"/></div>
              <div className="duel-selects">
                <label>SERVER A<select value={duelA} onChange={e => setDuelA(e.target.value)}><option value="">Select a public server</option>{sorted.map(s => <option key={s.id} value={s.id}>{s.name.slice(0, 80)}</option>)}</select></label>
                <div className="versus">VS</div>
                <label>SERVER B<select value={duelB} onChange={e => setDuelB(e.target.value)}><option value="">Select a public server</option>{sorted.map(s => <option key={s.id} value={s.id}>{s.name.slice(0, 80)}</option>)}</select></label>
              </div>
              <div className="duel-score">
                <DuelSide server={duelOne} letter="A"/>
                <div className="duel-middle"><span>PLAYER COUNT</span><b>VS</b><small>LIVE SNAPSHOT</small></div>
                <DuelSide server={duelTwo} letter="B"/>
              </div>
              {duelOne && duelTwo && <div className="duel-result">{duelOne.players === duelTwo.players ? "It's a tie right now." : `${duelOne.players > duelTwo.players ? duelOne.name : duelTwo.name} leads by ${fmt(Math.abs(duelOne.players - duelTwo.players))} players.`}</div>}
              <p className="fine-print">Historical duel graphs require persistent snapshots. This initial build compares live snapshots only; it does not fabricate past player counts.</p>
            </div>
            <div className="panel duel-info">
              <div className="eyebrow">PERFORMANCE NOTES</div><h3>Beyond the <em>numbers.</em></h3>
              <p>Jumlah pemain adalah salah satu sinyal aktivitas, bukan satu-satunya ukuran kualitas server. Gunakan ranking sebagai indikator komunitas, bukan penilaian mutlak.</p>
              <div className="note-row"><span className="note-icon"><Activity size={16}/></span><div><b>Player activity</b><small>Snapshot jumlah pemain saat ini.</small></div></div>
              <div className="note-row"><span className="note-icon"><ShieldCheck size={16}/></span><div><b>Transparent sourcing</b><small>Data publik dan keterbatasannya ditampilkan jelas.</small></div></div>
              <div className="note-row"><span className="note-icon"><ArrowUpRight size={16}/></span><div><b>Future analytics</b><small>Tren 24 jam dan 30 hari setelah storage aktif.</small></div></div>
            </div>
          </section>

          <section className="panel world-panel" id="worldmap">
            <div className="panel-head"><div><div className="eyebrow">GEOGRAPHIC INTELLIGENCE</div><h3>World <em>Map</em></h3><p>World map 2D untuk eksplorasi data server berdasarkan negara.</p></div><span className="count-tag">BETA VIEW</span></div>
            <div className="world-map">
              <svg viewBox="0 0 1000 410" role="img" aria-label="Stylized 2D world map illustration" className="map-svg">
                <defs><pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse"><path d="M32 0H0V32" fill="none" stroke="currentColor" strokeOpacity=".09" strokeWidth="1"/></pattern></defs>
                <rect width="1000" height="410" fill="url(#grid)"/>
                <g fill="#26272a" stroke="#4b4c50" strokeWidth="1.2">
                  <path d="M94 82l30-23 52-5 26 20 34 4 18 22-11 21-29 2-13 24-24 8-13 28-25-4-13-35-23-16-17-26z"/>
                  <path d="M225 182l30 6 22 24-3 34-19 20-8 41-19 35-16-20-5-36-18-29 10-35z"/>
                  <path d="M423 77l26-18 43 4 23 14 31-4 18 14 39-2 25 21-10 15-33 4-12 22-32 1-16 23-27-4-18-22-22-2-19-22-26-6-8-19z"/>
                  <path d="M473 169l32-5 27 21 17 37-9 38-19 42-25 39-21-12-14-42-18-26 5-39 15-22z"/>
                  <path d="M605 93l35-20 54 6 32 19 50-4 29 15 35-3 29 25-16 18-44-5-15 21-38-3-23 22-34-12-20-25-32 4-23-22-23-5z"/>
                  <path d="M760 217l38-14 49 10 25 26-12 28-34 7-24-15-30 1-22-21z"/>
                  <path d="M850 302l17-8 19 12-5 18-18 7-14-12z"/>
                  <path d="M350 95l17-9 18 6 3 15-14 9-18-6z"/>
                </g>
                <g fill="#ff3939" stroke="#ff3939">
                  <circle cx="190" cy="135" r="4"/><circle cx="502" cy="121" r="4"/><circle cx="514" cy="222" r="4"/><circle cx="670" cy="141" r="4"/><circle cx="748" cy="174" r="4"/><circle cx="801" cy="237" r="4"/>
                  <circle cx="670" cy="141" r="12" fillOpacity=".12"/><circle cx="670" cy="141" r="20" fill="none" strokeOpacity=".35"/>
                </g>
                <text x="190" y="119" fill="#ff6969" fontSize="11">AMERICAS</text><text x="474" y="105" fill="#ff6969" fontSize="11">EUROPE</text><text x="680" y="126" fill="#ff6969" fontSize="11">ASIA</text>
                <text x="500" y="385" textAnchor="middle" fill="#8d8d92" fontSize="12" letterSpacing="3">GEOGRAPHIC DATA COVERAGE DEPENDS ON PUBLIC SERVER METADATA</text>
              </svg>
              <div className="map-legend"><span><i className="legend-dot"/> Detected region marker</span><span>Country-level coverage: partial</span></div>
            </div>
            <div className="notice"><Globe2 size={18}/><div><strong>Map status: visual prototype</strong><p>Peta ini belum menempatkan setiap server berdasarkan koordinat nyata. Cfx.re tidak selalu menerbitkan lokasi geografis yang akurat; lokasi negara perlu metadata yang dapat diverifikasi.</p></div></div>
          </section>

          <section className="news-section" id="news">
            <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> COMMUNITY DESK</div><h2>Stay in the <em>loop.</em></h2><p>Follow kanal resmi FIVEM E-SPORTS untuk update berita dan ranking.</p></div></div>
            <div className="social-grid">
              <a className="social-card tiktok" href="https://www.tiktok.com/@fivemesports.id" target="_blank" rel="noreferrer"><div className="social-symbol">♪</div><div><span>FOLLOW ON TIKTOK</span><h3>@fivemesports.id</h3><p>Breaking news, server spotlight, dan update komunitas.</p></div><ExternalLink size={17}/></a>
              <a className="social-card instagram" href="https://www.instagram.com/fivemesports.id/" target="_blank" rel="noreferrer"><div className="social-symbol">◎</div><div><span>FOLLOW ON INSTAGRAM</span><h3>@fivemesports.id</h3><p>Visual ranking, poster berita, dan informasi terbaru.</p></div><ExternalLink size={17}/></a>
            </div>
          </section>

          <section className="official-section">
            <div><div className="eyebrow">OFFICIAL RESOURCES</div><h2>Go to the <em>source.</em></h2><p>Link resmi untuk download FiveM dan informasi GTA V.</p></div>
            <div className="official-links">{officialLinks.map(link => <a key={link.label} href={link.href} target="_blank" rel="noreferrer"><span><b>{link.label}</b><small>{link.desc}</small></span><ExternalLink size={16}/></a>)}</div>
          </section>
          <footer><div className="footer-brand"><img src="/logo.png" alt="Logo"/><b>FIVEM E-SPORTS</b></div><span>Independent community platform · Est. 2026</span><span>FiveM is a trademark of its respective owner. Not affiliated with Cfx.re or Rockstar Games.</span></footer>
        </section>
      </section>
    </main>
  );
}

function Stat({ icon, label, value, foot, live = false }: { icon: React.ReactNode; label: string; value: string; foot: string; live?: boolean }) {
  return <div className="stat-card"><div className="stat-top"><span className="stat-icon">{icon}</span>{live && <span className="live-mini"><i/> LIVE</span>}</div><span className="stat-label">{label}</span><strong className={value === "OFFLINE" ? "stat-offline" : ""}>{value}</strong><small>{foot}</small></div>;
}

function ServerTable({ servers, empty }: { servers: Server[]; empty: string }) {
  return <div className="table-wrap"><table><thead><tr><th>RANK</th><th>SERVER</th><th>PLAYERS</th><th>CAPACITY</th><th>UTILIZATION</th><th>STATUS</th></tr></thead><tbody>{servers.length ? servers.map((s, i) => {
    const pct = s.maxPlayers > 0 ? Math.min(100, Math.round(s.players / s.maxPlayers * 100)) : 0;
    return <tr key={s.id}><td><span className={`rank ${i < 3 ? "rank-top" : ""}`}>{String(i + 1).padStart(2, "0")}</span></td><td><div className="server-name"><span className="server-avatar">{s.name.replace(/[^a-z0-9]/gi, "").slice(0, 1).toUpperCase() || "F"}</span><span><b>{s.name}</b><small>{s.country === "Indonesia" ? "🇮🇩 Indonesia signal detected" : s.language !== "Unknown" ? `Language / locale: ${s.language}` : "Public Cfx.re listing"}</small></span></div></td><td><b className="player-count">{fmt(s.players)}</b></td><td>{s.maxPlayers ? fmt(s.maxPlayers) : "—"}</td><td><div className="utilization"><div><span style={{ width: `${pct}%` }}/></div><small>{s.maxPlayers ? `${pct}%` : "N/A"}</small></div></td><td><span className="server-status"><i/> Listed</span></td></tr>;
  }) : <tr><td colSpan={6} className="empty-cell">{empty}</td></tr>}</tbody></table></div>;
}

function DuelSide({ server, letter }: { server?: Server; letter: string }) {
  return <div className="duel-side"><span className="duel-label">SERVER {letter}</span><strong>{server ? fmt(server.players) : "—"}</strong><span className="duel-server-name">{server ? server.name : "Choose a server"}</span><div className="duel-bar"><span style={{ width: server ? `${Math.min(100, server.maxPlayers ? server.players / server.maxPlayers * 100 : 0)}%` : "0%" }}/></div><small>{server ? `${server.maxPlayers ? fmt(server.maxPlayers) + " slots" : "Capacity unavailable"}` : "No selection"}</small></div>;
}
