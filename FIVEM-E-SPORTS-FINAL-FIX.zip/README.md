# FIVEM E-SPORTS

Dashboard Next.js untuk memantau daftar publik server FiveM, ranking berdasarkan jumlah pemain, perbandingan server, social links, dan tautan resmi.

## Data server otomatis

Endpoint `/api/servers` menggunakan paket `cfx-api` untuk membaca dan mendekode stream Protobuf dari browser server publik Cfx.re. Tidak perlu memasukkan ID server secara manual. Server diurutkan berdasarkan jumlah pemain saat data diambil. Untuk mengurangi beban pada sumber publik, respons di-cache selama 5 menit.

Catatan penting:
- Daftar master publik dapat berukuran besar dan endpoint dapat berubah atau membatasi akses. Jika sumber gagal, API mengembalikan error nyata dan dashboard tidak mengarang statistik.
- API browser server Cfx.re bukan kontrak publik resmi yang dijamin stabil. Paket decoder merupakan proyek pihak ketiga yang membaca sumber publik Cfx.re.
- “Indonesia” diperkirakan dari locale, nama, dan tag server. Ini bukan klasifikasi negara yang dijamin akurat.
- Top 10 Indonesia adalah daftar kandidat berdasarkan metadata publik yang cocok, bukan daftar resmi Cfx.re.
- Ranking historis 30 hari belum aktif. Itu membutuhkan database persisten dan tugas terjadwal untuk menyimpan snapshot.
- Peta 2D adalah visual prototipe, bukan lokasi server yang diverifikasi.

## Menjalankan lokal

Gunakan Node.js 20 atau lebih baru:

```bash
npm install
npm run dev
```

Buka `http://localhost:3000`.

## Build dan deploy

```bash
npm run build
```

Push ke GitHub, lalu hubungkan repository ke Vercel sebagai proyek Next.js. Root Directory harus menunjuk ke folder yang berisi `package.json`, `app/`, dan `public/`. Pastikan deployment terbaru berstatus `Ready`, kemudian uji `/api/servers`.

Jika Vercel menampilkan error 502, buka Vercel → Project → Logs / Functions untuk membaca pesan API. Build sukses saja tidak membuktikan bahwa Cfx.re dapat diakses dari server produksi.
